#include <algorithm>
#include <iostream>
#include <numeric>
#include <vector>
#include "path_planner.h"
#include "communicator.h"

// test main program

int main()
{
    communicator_main();
    return 0;
}