#include <iostream>

#ifndef COMMUNICATOR
#define COMMUNICATOR

#include <iostream>
#include <string>
#include <vector>
#include <chrono> // 用于延时
#include <thread> // 用于延时
#include "serialib.h" // 包含 serialib 头文件

int communicator_main();

#endif